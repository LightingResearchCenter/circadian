function CS = CSCalc_postBerlin_12Aug2011(CLA)

CS = .7*(1 - (1./(1 + (CLA/355.7).^(1.1026))));